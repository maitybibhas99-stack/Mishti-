package com.mishti.assistant.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.BuildConfig
import com.mishti.assistant.Prefs

// Female-sounding voices first. The Live model decides which ones it really supports.
private val VOICES = listOf(
    "Aoede", "Kore", "Leda", "Zephyr", "Callirhoe", "Autonoe",
    "Despina", "Erinome", "Sulafat", "Vindemiatrix", "Achernar", "Laomedeia"
)

@Composable
fun SettingsScreen(prefs: Prefs, onSaved: () -> Unit, onBack: () -> Unit) {
    var key by remember { mutableStateOf(prefs.typed("api_key")) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(prefs.typed("model")) }
    var voice by remember { mutableStateOf(prefs.voice) }
    var name by remember { mutableStateOf(prefs.userName) }

    Column(
        Modifier
            .fillMaxSize()
            .background(MishtiColors.Bg)
            .systemBarsPadding()
            .imePadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MishtiColors.Text)
            }
            Text(
                "Settings",
                color = MishtiColors.Text,
                fontFamily = FontFamily.Serif,
                fontSize = 22.sp,
                modifier = Modifier.padding(start = 6.dp)
            )
        }

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Label("Tomar naam (optional)")
            Field(name, { name = it }, "Jemon: Bibhas")

            Label("Gemini API key")
            Field(
                key,
                { key = it },
                "AIza...",
                visual = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardType = KeyboardType.Password
            )
            Text(
                if (showKey) "Lukao" else "Dekhao",
                color = MishtiColors.Coral,
                fontSize = 14.sp,
                modifier = Modifier
                    .padding(top = 8.dp)
                    .clickable { showKey = !showKey }
            )
            Hint("aistudio.google.com theke free key nao. Key shudhu ei phone-e thake, Google chhara kothao jay na.")

            Label("Model (khali rakhle default)")
            Field(model, { model = it }, BuildConfig.GEMINI_MODEL)
            Hint("Connection-e model error ashle AI Studio-te Live model-er notun naam dekhe ekhane boshao.")

            Label("Voice")
            VOICES.chunked(3).forEach { row ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    row.forEach { v ->
                        VoiceChip(v, v == voice, Modifier.weight(1f)) { voice = v }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White)
                .clickable {
                    prefs.apiKey = key
                    prefs.model = model
                    prefs.voice = voice
                    prefs.userName = name
                    onSaved()
                }
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Save", color = Color.Black, fontSize = 16.sp)
        }
    }
}

@Composable
private fun Label(t: String) {
    Text(t, color = MishtiColors.Text, fontSize = 15.sp, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
}

@Composable
private fun Hint(t: String) {
    Text(t, color = MishtiColors.TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    visual: VisualTransformation = VisualTransformation.None,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    val shape = RoundedCornerShape(16.dp)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        visualTransformation = visual,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = TextStyle(color = MishtiColors.Text, fontSize = 16.sp),
        cursorBrush = SolidColor(MishtiColors.Coral),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(MishtiColors.Surface, shape)
                    .border(1.dp, MishtiColors.SurfaceHigh, shape)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                if (value.isEmpty()) Text(placeholder, color = MishtiColors.TextDim, fontSize = 16.sp, maxLines = 1)
                inner()
            }
        }
    )
}

@Composable
private fun VoiceChip(name: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) MishtiColors.Coral.copy(alpha = 0.18f) else MishtiColors.Surface)
            .border(1.dp, if (selected) MishtiColors.Coral else MishtiColors.SurfaceHigh, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name,
            color = if (selected) MishtiColors.Coral else MishtiColors.Text,
            fontSize = 13.sp,
            maxLines = 1
        )
    }
}
