package com.mishti.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String)

enum class Phase { Idle, Connecting, Listening, Speaking }

data class Ui(
    val messages: List<ChatMessage> = emptyList(),
    val phase: Phase = Phase.Idle,
    val voiceOpen: Boolean = false,
    val muted: Boolean = false,
    val levels: List<Float> = List(BARS) { 0f },
    val error: String? = null,
) {
    companion object {
        const val BARS = 41
    }
}

class MainViewModel(app: Application) : AndroidViewModel(app), GeminiLiveClient.Listener {

    private val _ui = MutableStateFlow(Ui())
    val ui: StateFlow<Ui> = _ui.asStateFlow()

    val prefs = Prefs(app)
    private val audio = AudioEngine(app)
    private var client: GeminiLiveClient? = null
    private var ticker: Job? = null
    private var nextId = 1L
    private val pendingText = mutableListOf<String>()

    @Volatile private var ready = false
    @Volatile private var micStarted = false
    private var smooth = 0f

    // ---------------------------------------------------------------- public API

    fun openVoice() {
        _ui.update { it.copy(voiceOpen = true, error = null) }
        if (!ensureSession()) return
        if (ready) startMicIfNeeded()
    }

    fun closeVoice() {
        _ui.update { it.copy(voiceOpen = false) }
        stopSession()
    }

    fun toggleMute() {
        _ui.update { it.copy(muted = !it.muted) }
    }

    fun sendText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        addOrAppend(fromUser = true, text = clean, forceNew = true)
        if (!ensureSession()) return
        if (ready) client?.sendText(clean) else synchronized(pendingText) { pendingText.add(clean) }
    }

    fun newChat() {
        stopSession()
        _ui.update { Ui() }
    }

    fun dismissError() {
        _ui.update { it.copy(error = null) }
    }

    // ---------------------------------------------------------------- session

    private fun ensureSession(): Boolean {
        if (client != null) return true
        val key = prefs.apiKey
        if (key.isBlank()) {
            _ui.update {
                it.copy(
                    voiceOpen = false,
                    error = "Gemini API key nei. Upore Settings-e giye key dao."
                )
            }
            return false
        }
        ready = false
        micStarted = false
        _ui.update { it.copy(phase = Phase.Connecting) }
        audio.startPlayback()
        client = GeminiLiveClient(key, prefs.model, this).also {
            it.connect(Persona.prompt(prefs.userName), prefs.voice)
        }
        startTicker()
        return true
    }

    private fun stopSession() {
        ticker?.cancel()
        ticker = null
        client?.close()
        client = null
        ready = false
        micStarted = false
        audio.stopMic()
        audio.stopPlayback()
        synchronized(pendingText) { pendingText.clear() }
        smooth = 0f
        _ui.update { it.copy(phase = Phase.Idle, levels = List(Ui.BARS) { 0f }) }
    }

    private fun startMicIfNeeded() {
        if (micStarted || !_ui.value.voiceOpen) return
        val ok = audio.startMic { chunk ->
            if (!_ui.value.muted) client?.sendAudio(chunk)
        }
        if (ok) {
            micStarted = true
        } else {
            _ui.update { it.copy(voiceOpen = false, error = "Mic chalu korte parlam na. Permission dekho.") }
            stopSession()
        }
    }

    private fun startTicker() {
        ticker?.cancel()
        ticker = viewModelScope.launch {
            while (isActive) {
                val speaking = audio.outstandingMs() > 0
                val raw = when {
                    speaking -> audio.outLevel
                    micStarted && !_ui.value.muted -> audio.micLevel
                    else -> 0f
                }
                smooth = if (raw > smooth) smooth + (raw - smooth) * 0.6f else smooth + (raw - smooth) * 0.18f
                val phase = when {
                    !ready -> Phase.Connecting
                    speaking -> Phase.Speaking
                    else -> Phase.Listening
                }
                _ui.update { s ->
                    s.copy(phase = phase, levels = s.levels.drop(1) + smooth)
                }
                delay(40)
            }
        }
    }

    // ---------------------------------------------------------------- transcript

    private fun addOrAppend(fromUser: Boolean, text: String, forceNew: Boolean = false) {
        _ui.update { s ->
            val last = s.messages.lastOrNull()
            if (!forceNew && last != null && last.fromUser == fromUser) {
                s.copy(messages = s.messages.dropLast(1) + last.copy(text = last.text + text))
            } else {
                s.copy(messages = s.messages + ChatMessage(nextId++, fromUser, text))
            }
        }
    }

    // ---------------------------------------------------------------- Gemini callbacks

    override fun onReady() {
        ready = true
        _ui.update { it.copy(phase = Phase.Listening) }
        val queued = synchronized(pendingText) { pendingText.toList().also { pendingText.clear() } }
        queued.forEach { client?.sendText(it) }
        startMicIfNeeded()
    }

    override fun onAudio(pcm: ByteArray) = audio.play(pcm)

    override fun onInputText(text: String) = addOrAppend(fromUser = true, text = text)

    override fun onOutputText(text: String) = addOrAppend(fromUser = false, text = text)

    override fun onInterrupted() = audio.interrupt()

    override fun onTurnComplete() {}

    override fun onClosed(reason: String?) {
        viewModelScope.launch {
            stopSession()
            _ui.update { it.copy(voiceOpen = false, error = "Connection bondho hoye gelo. Abar try koro.") }
        }
    }

    override fun onError(message: String) {
        viewModelScope.launch {
            stopSession()
            _ui.update { it.copy(voiceOpen = false, error = message) }
        }
    }

    override fun onCleared() {
        stopSession()
        super.onCleared()
    }
}
