package com.mishti.assistant

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

/** Mic capture (16 kHz) and speaker playback (24 kHz) for the Gemini Live session. */
class AudioEngine(context: Context) {

    companion object {
        const val IN_RATE = 16000
        const val OUT_RATE = 24000
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // ---- levels (0..1), read by the UI ticker ----
    @Volatile var micLevel = 0f
        private set
    @Volatile var outLevel = 0f
        private set

    // ---- mic ----
    private var record: AudioRecord? = null
    private var micThread: Thread? = null
    @Volatile private var micRunning = false
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    private var agc: AutomaticGainControl? = null

    @SuppressLint("MissingPermission")
    fun startMic(onChunk: (ByteArray) -> Unit): Boolean {
        if (micRunning) return true
        val minBuf = AudioRecord.getMinBufferSize(
            IN_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBuf <= 0) return false
        val chunkBytes = IN_RATE / 25 * 2 // 40 ms
        val rec = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                IN_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, chunkBytes * 4)
            )
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        val sid = rec.audioSessionId
        if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(sid)?.also { it.enabled = true }
        if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(sid)?.also { it.enabled = true }
        if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(sid)?.also { it.enabled = true }

        record = rec
        micRunning = true
        rec.startRecording()
        micThread = Thread({
            val buf = ByteArray(chunkBytes)
            while (micRunning) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) {
                    micLevel = rms(buf, n)
                    onChunk(buf.copyOf(n))
                } else if (n < 0) {
                    break
                }
            }
        }, "mishti-mic").also { it.start() }
        return true
    }

    fun stopMic() {
        micRunning = false
        try { micThread?.join(300) } catch (_: InterruptedException) {}
        micThread = null
        try { record?.stop() } catch (_: Exception) {}
        record?.release()
        record = null
        aec?.release(); aec = null
        ns?.release(); ns = null
        agc?.release(); agc = null
        micLevel = 0f
    }

    // ---- playback ----
    private var track: AudioTrack? = null
    private var writer: Thread? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    private val framesWritten = AtomicLong(0)
    @Volatile private var writerRunning = false
    @Volatile private var generation = 0

    @Suppress("DEPRECATION")
    fun startPlayback() {
        if (track != null) return
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = true

        val minBuf = AudioTrack.getMinBufferSize(
            OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(OUT_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(maxOf(minBuf, OUT_RATE / 5 * 2)) // ~200 ms
            .build()
        t.play()
        track = t
        framesWritten.set(0)

        writerRunning = true
        writer = Thread({
            val slice = OUT_RATE / 50 * 2 // 20 ms
            while (writerRunning) {
                val chunk = try { queue.take() } catch (e: InterruptedException) { break }
                val gen = generation
                var off = 0
                while (off < chunk.size && writerRunning && gen == generation) {
                    val len = min(slice, chunk.size - off)
                    outLevel = rms(chunk, off, len)
                    val w = t.write(chunk, off, len)
                    if (w <= 0) break
                    framesWritten.addAndGet((w / 2).toLong())
                    off += w
                }
            }
        }, "mishti-play").also { it.start() }
    }

    fun play(pcm24k: ByteArray) {
        if (track == null) return
        queue.offer(pcm24k)
    }

    /** User barged in: drop everything that is queued or buffered. */
    fun interrupt() {
        val t = track ?: return
        generation++
        queue.clear()
        try {
            t.pause()
            t.flush()
            t.play()
        } catch (_: Exception) {}
        framesWritten.set(0)
        outLevel = 0f
    }

    /** Roughly how many ms of speech are still waiting to be heard. */
    fun outstandingMs(): Long {
        val t = track ?: return 0
        if (queue.isNotEmpty()) return 100
        val remaining = framesWritten.get() - t.playbackHeadPosition.toLong()
        if (remaining <= 0) {
            outLevel = 0f
            return 0
        }
        return remaining * 1000 / OUT_RATE
    }

    @Suppress("DEPRECATION")
    fun stopPlayback() {
        writerRunning = false
        writer?.interrupt()
        writer = null
        queue.clear()
        try { track?.stop() } catch (_: Exception) {}
        track?.release()
        track = null
        outLevel = 0f
        audioManager.isSpeakerphoneOn = false
        audioManager.mode = AudioManager.MODE_NORMAL
    }

    private fun rms(buf: ByteArray, len: Int): Float = rms(buf, 0, len)

    private fun rms(buf: ByteArray, off: Int, len: Int): Float {
        var sum = 0.0
        var count = 0
        var i = off
        val end = off + len - 1
        while (i < end) {
            val s = ((buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)).toShort().toInt()
            sum += (s * s).toDouble()
            count++
            i += 2
        }
        if (count == 0) return 0f
        val r = sqrt(sum / count).toFloat() / 32768f
        return min(1f, abs(r) * 5f)
    }
}
