package com.mishti.assistant

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Minimal Gemini Live (BidiGenerateContent) WebSocket client.
 * Audio in: 16 kHz mono PCM16. Audio out: 24 kHz mono PCM16.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val listener: Listener,
) {
    interface Listener {
        fun onReady()
        fun onAudio(pcm: ByteArray)
        fun onInputText(text: String)
        fun onOutputText(text: String)
        fun onInterrupted()
        fun onTurnComplete()
        fun onClosed(reason: String?)
        fun onError(message: String)
    }

    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var ws: WebSocket? = null

    @Volatile
    var ready = false
        private set

    @Volatile
    private var closedByUs = false

    fun connect(systemPrompt: String, voice: String) {
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()
        ws = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(buildSetup(systemPrompt, voice).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                ready = false
                if (!closedByUs) listener.onClosed(reason.ifBlank { "code $code" })
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                ready = false
                if (closedByUs) return
                val code = response?.code
                listener.onError(
                    if (code != null) "Connection failed ($code). API key ba model check koro."
                    else "Connection failed: ${t.message ?: "unknown"}"
                )
            }
        })
    }

    private fun buildSetup(systemPrompt: String, voice: String): JSONObject {
        val setup = JSONObject()
            .put("model", "models/${model.removePrefix("models/")}")
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put(
                                "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)
                            )
                        )
                    )
            )
            .put(
                "systemInstruction", JSONObject().put(
                    "parts", JSONArray().put(JSONObject().put("text", systemPrompt))
                )
            )
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        return JSONObject().put("setup", setup)
    }

    private fun handle(raw: String) {
        val json = try {
            JSONObject(raw)
        } catch (e: Exception) {
            return
        }

        if (json.has("setupComplete")) {
            ready = true
            listener.onReady()
            return
        }

        val content = json.optJSONObject("serverContent") ?: return

        if (content.optBoolean("interrupted", false)) {
            listener.onInterrupted()
        }

        content.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                val data = inline.optString("data")
                if (data.isNotEmpty()) {
                    listener.onAudio(Base64.decode(data, Base64.NO_WRAP))
                }
            }
        }

        content.optJSONObject("inputTranscription")?.optString("text")?.let {
            if (it.isNotEmpty()) listener.onInputText(it)
        }
        content.optJSONObject("outputTranscription")?.optString("text")?.let {
            if (it.isNotEmpty()) listener.onOutputText(it)
        }

        if (content.optBoolean("turnComplete", false)) {
            listener.onTurnComplete()
        }
    }

    fun sendAudio(pcm16k: ByteArray) {
        if (!ready) return
        val msg = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "audio", JSONObject()
                    .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000")
            )
        )
        ws?.send(msg.toString())
    }

    fun sendText(text: String) {
        if (!ready) return
        val msg = JSONObject().put("realtimeInput", JSONObject().put("text", text))
        ws?.send(msg.toString())
    }

    fun close() {
        closedByUs = true
        ready = false
        ws?.close(1000, "bye")
        ws = null
    }
}
