package com.mishti.assistant

import android.content.Context

/**
 * On-device settings. Values typed in the Settings screen win; if empty, the
 * build-time values from local.properties (BuildConfig) are used as a fallback.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("mishti", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "").orEmpty().ifBlank { BuildConfig.GEMINI_API_KEY }
        set(v) = sp.edit().putString("api_key", v.trim()).apply()

    var model: String
        get() = sp.getString("model", "").orEmpty().ifBlank { BuildConfig.GEMINI_MODEL }
        set(v) = sp.edit().putString("model", v.trim()).apply()

    var voice: String
        get() = sp.getString("voice", "").orEmpty().ifBlank { BuildConfig.GEMINI_VOICE }
        set(v) = sp.edit().putString("voice", v.trim()).apply()

    var userName: String
        get() = sp.getString("user_name", "").orEmpty()
        set(v) = sp.edit().putString("user_name", v.trim()).apply()

    /** Raw typed values, so the Settings screen does not show the build fallback as if it were typed. */
    fun typed(key: String): String = sp.getString(key, "").orEmpty()
}
