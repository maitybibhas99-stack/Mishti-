package com.mishti.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mishti.assistant.Phase
import com.mishti.assistant.Ui
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

@Composable
fun VoiceScreen(
    ui: Ui,
    onClose: () -> Unit,
    onToggleMute: () -> Unit,
) {
    BackHandler(onBack = onClose)

    val status = when {
        ui.muted -> "Mic bondho"
        ui.phase == Phase.Connecting -> "Connect hochhe..."
        ui.phase == Phase.Speaking -> "Mishti bolchhe"
        else -> "Shunchi..."
    }
    val lastLine = ui.messages.lastOrNull()?.text.orEmpty()

    Column(
        Modifier
            .fillMaxSize()
            .background(MishtiColors.Bg)
            .systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(72.dp))
        Text(
            "Mishti",
            color = MishtiColors.Text,
            fontFamily = FontFamily.Serif,
            fontSize = 24.sp
        )

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Waveform(
                levels = ui.levels,
                active = ui.phase == Phase.Speaking || (ui.phase == Phase.Listening && !ui.muted),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .padding(horizontal = 28.dp)
            )
        }

        Text(
            status,
            color = MishtiColors.TextDim,
            fontSize = 15.sp,
            modifier = Modifier.padding(bottom = 10.dp)
        )
        Text(
            lastLine,
            color = MishtiColors.Text,
            fontFamily = FontFamily.Serif,
            fontSize = 16.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .padding(horizontal = 32.dp)
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 36.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton(
                background = MishtiColors.Surface,
                onClick = onToggleMute
            ) {
                Icon(
                    if (ui.muted) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Mute",
                    tint = if (ui.muted) MishtiColors.Coral else MishtiColors.Text
                )
            }
            Spacer(Modifier.size(28.dp))
            RoundButton(
                background = MishtiColors.Danger,
                onClick = onClose
            ) {
                Icon(Icons.Default.Close, contentDescription = "Shesh", tint = Color.White)
            }
        }
    }
}

@Composable
private fun RoundButton(background: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun Waveform(levels: List<Float>, active: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = levels.size
        if (n == 0) return@Canvas
        val slot = size.width / n
        val barW = slot * 0.55f
        val minH = barW
        val maxH = size.height
        val color = if (active) MishtiColors.Coral else MishtiColors.Coral.copy(alpha = 0.45f)

        for (i in 0 until n) {
            val envelope = 0.3f + 0.7f * sin(PI * i / (n - 1)).toFloat()
            val level = levels[i].coerceIn(0f, 1f).pow(0.75f)
            val h = max(minH, maxH * level * envelope)
            val x = slot * i + (slot - barW) / 2f
            drawRoundRect(
                color = color,
                topLeft = Offset(x, (size.height - h) / 2f),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f)
            )
        }
    }
}
