# Mishti

Android voice assistant. Kotlin + Jetpack Compose, Gemini Live voice-to-voice.
Package: com.mishti.assistant

## Build on GitHub (no Android Studio needed)
1. Make a new GitHub repo and upload everything in this folder, including the hidden `.github` folder.
2. Push to `main`. Open the **Actions** tab. If the run has not started, open **Build Mishti APK** and press **Run workflow**.
3. When it turns green, open the run, download the **Mishti-debug-apk** artifact, unzip it and install `app-debug.apk`.

## First run
1. Open the app, tap the gear icon (top right) -> paste your Gemini API key (aistudio.google.com) -> Save.
2. Tap the white waveform button and talk. Allow the microphone when asked.

The key is stored only on the phone. If the connection fails with a model error, put the current Live model
name from AI Studio into Settings -> Model.

## Android Studio (optional)
Open the folder, let Gradle sync, run. You can also put `GEMINI_API_KEY=...` in `local.properties` as a fallback.

## Steps
1. Voice chat, Claude-style UI, Settings
2. Phone control: call, SMS, open apps (this version)
3. Settings toggles (WiFi, Bluetooth, torch, volume, brightness)
4. Accessibility service: tap, scroll, back, home, type
