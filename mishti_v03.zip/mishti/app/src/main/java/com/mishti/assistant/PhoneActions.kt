package com.mishti.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/** The phone actions Mishti can trigger through Gemini tool calls. Every result goes back to the model as JSON. */
class PhoneActions(private val ctx: Context) {

    private companion object {
        // Column names written out so we do not depend on inherited Java constants.
        const val COL_NAME = "display_name"
        const val COL_NUMBER = "data1"
        const val COL_TYPE = "data2"
    }

    fun run(name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "call_contact" -> callContact(args.optString("name_or_number"))
            "send_sms" -> sendSms(args.optString("to"), args.optString("message"))
            "open_app" -> openApp(args.optString("app_name"))
            else -> err("Ei tool-ta nei: $name")
        }
    } catch (e: Exception) {
        err("${e.javaClass.simpleName}: ${e.message}")
    }

    // ------------------------------------------------------------------ call / sms

    private fun callContact(query: String): JSONObject {
        if (!has(Manifest.permission.CALL_PHONE)) {
            return err("Call permission nei. User-ke bolo Settings > Apps > Mishti > Permissions theke Phone allow korte.")
        }
        val r = resolve(query)
        r.error?.let { return it }
        val intent = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", r.number, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return ok("${r.label}-ke call lagano hocche.")
    }

    private fun sendSms(to: String, message: String): JSONObject {
        if (message.isBlank()) return err("Message khali. User-ke jiggesh koro ki likhbe.")
        if (!has(Manifest.permission.SEND_SMS)) {
            return err("SMS permission nei. User-ke bolo Settings > Apps > Mishti > Permissions theke SMS allow korte.")
        }
        val r = resolve(to)
        r.error?.let { return it }
        val sms = smsManager()
        val parts = sms.divideMessage(message)
        sms.sendMultipartTextMessage(r.number, null, parts, null, null)
        return ok("${r.label}-ke SMS pathano hoyeche.")
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private class Resolved(val number: String? = null, val label: String? = null, val error: JSONObject? = null)

    /** Turns "Rahul", "Rahul Das" or "98300 12345" into a number. Ambiguous names are handed back to the model. */
    private fun resolve(query: String): Resolved {
        val q = query.trim()
        if (q.isEmpty()) return Resolved(error = err("Kar naam ba number? User-ke jiggesh koro."))

        val looksLikeNumber = q.count { it.isDigit() } >= 3 && q.all { it.isDigit() || it in "+ -()" }
        if (looksLikeNumber) return Resolved(number = q.filter { it.isDigit() || it == '+' }, label = q)

        if (!has(Manifest.permission.READ_CONTACTS)) {
            return Resolved(error = err("Contacts permission nei. User-ke bolo Settings > Apps > Mishti > Permissions theke Contacts allow korte."))
        }

        val rows = mutableListOf<Triple<String, String, Int>>() // name, number, type
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(COL_NAME, COL_NUMBER, COL_TYPE),
            "$COL_NAME LIKE ?",
            arrayOf("%$q%"),
            null
        )?.use { c ->
            while (c.moveToNext()) {
                rows.add(Triple(c.getString(0).orEmpty(), c.getString(1).orEmpty(), c.getInt(2)))
            }
        }
        if (rows.isEmpty()) return Resolved(error = err("'$q' naame kono contact paini."))

        val names = rows.map { it.first }.distinct()
        val chosen = when {
            names.size == 1 -> names[0]
            else -> names.firstOrNull { it.equals(q, ignoreCase = true) }
        }
        if (chosen == null) {
            val json = JSONObject()
                .put("status", "ambiguous")
                .put("matches", JSONArray(names.take(6)))
                .put(
                    "message",
                    "Ekadhik contact mile geche. User-ke jiggesh koro kon-ta, tarpor full naam diye abar try koro."
                )
            return Resolved(error = json)
        }

        val mine = rows.filter { it.first == chosen }
        val best = mine.firstOrNull { it.third == Phone.TYPE_MOBILE } ?: mine.first()
        val number = best.second.filter { it.isDigit() || it == '+' }
        if (number.isEmpty()) return Resolved(error = err("$chosen-er number paini."))
        return Resolved(number = number, label = chosen)
    }

    // ------------------------------------------------------------------ open app

    private fun openApp(appName: String): JSONObject {
        val q = appName.trim().lowercase()
        if (q.isEmpty()) return err("Kon app? User-ke jiggesh koro.")

        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }

        val exact = apps.filter { it.first.lowercase() == q }
        val hits = if (exact.isNotEmpty()) exact else apps.filter { it.first.lowercase().contains(q) }
        if (hits.isEmpty()) return err("'$appName' naame kono app paini.")
        if (hits.size > 1) {
            return JSONObject()
                .put("status", "ambiguous")
                .put("matches", JSONArray(hits.take(6).map { it.first }))
                .put("message", "Ekadhik app mile geche. User-ke jiggesh koro kon-ta, tarpor exact naam diye abar try koro.")
        }

        val (label, pkg) = hits[0]
        val launch = pm.getLaunchIntentForPackage(pkg) ?: return err("$label khola gelo na.")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return ok("$label khola hocche.")
    }

    // ------------------------------------------------------------------ helpers

    private fun has(permission: String) =
        ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    private fun ok(msg: String) = JSONObject().put("status", "ok").put("message", msg)

    private fun err(msg: String) = JSONObject().put("status", "error").put("message", msg)
}
